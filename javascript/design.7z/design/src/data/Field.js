﻿
	Design.define('Design.data.Field',{
		constructor:function(data){
			Design.apply(this,data);
		}
	})